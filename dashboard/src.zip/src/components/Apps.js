const Apps = () => {
  return <h1>Apps</h1>;
};

export default Apps;
